#!/system/bin/sh
MODDIR=${0%/*}
CFG=$MODDIR/config.txt
INTERVAL_MS=500
APPLY_DELAY=0.6
[ -f "$CFG" ] && . "$CFG"
export PATH=/system/bin:/system/xbin:/apex/com.android.runtime/bin:$PATH
LIMIT=$((INTERVAL_MS / 10))

rm -f "$MODDIR/log.txt"
until [ "$(getprop sys.boot_completed)" = "1" ]; do sleep 3; done
sleep 8

PIDF=$MODDIR/.pid
if [ -f "$PIDF" ] && kill -0 "$(cat $PIDF)" 2>/dev/null; then exit 0; fi
echo $$ > "$PIDF"

set_max() {
  for b in /sys/class/backlight/*; do
    [ -f "$b/max_brightness" ] || continue
    cat "$b/max_brightness" > "$b/brightness" 2>/dev/null
  done
  ( timeout 5 cmd display set-brightness 1.0 >/dev/null 2>&1 & )
}

while true; do
  last=-1000
  # blocking read: zero CPU use until the kernel reports a key event
  getevent 2>/dev/null | while read -r line; do
    case "$line" in
      *"0001 0074 00000001"*|*KEY_POWER*DOWN*)
        read up _ < /proc/uptime
        now=${up%.*}${up#*.}
        if [ $((now - last)) -le "$LIMIT" ]; then
          last=-1000
          ( sleep $APPLY_DELAY; set_max; sleep 0.7; set_max; sleep 1.2; set_max ) &
        else
          last=$now
        fi
        ;;
    esac
  done
  sleep 5
done
