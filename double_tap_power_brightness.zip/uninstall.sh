#!/system/bin/sh
pkill -f double_tap_power_brightness 2>/dev/null
