package com.jama.powermaxlight;

import android.content.Context;
import android.provider.Settings;

import java.io.InputStream;

final class Brightness {
    private Brightness() {}

    static void apply(Context c) {
        runRoot("for b in /sys/class/backlight/*; do cat $b/max_brightness > $b/brightness; done; cmd display set-brightness 1.0");
        try {
            if (Settings.System.canWrite(c)) {
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE, 0);
                Settings.System.putInt(c.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
            }
        } catch (Exception ignored) {
        }
    }

    static boolean runRoot(String cmd) {
        try {
            Process p = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            p.getOutputStream().close();
            InputStream in = p.getInputStream();
            byte[] buf = new byte[1024];
            while (in.read(buf) != -1) { /* drain */ }
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
