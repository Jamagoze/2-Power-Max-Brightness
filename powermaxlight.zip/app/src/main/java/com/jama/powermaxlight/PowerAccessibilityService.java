package com.jama.powermaxlight;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PowerAccessibilityService extends AccessibilityService {

    private static final long TAP_MS = 500;
    private static final long SCREEN_MS = 1500;
    private static final long DEBOUNCE_MS = 3000;

    private volatile boolean running;
    private volatile Process proc;
    private Thread listener;
    private BroadcastReceiver screenRx;

    private long lastDown = 0;
    private long lastFire = 0;
    private long offAt = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        if (running) return;
        running = true;

        screenRx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String a = intent.getAction();
                long now = SystemClock.elapsedRealtime();
                if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                    offAt = now;
                } else if (Intent.ACTION_SCREEN_ON.equals(a)) {
                    if (offAt != 0 && now - offAt <= SCREEN_MS) {
                        offAt = 0;
                        fire();
                    }
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenRx, f);

        listener = new Thread(this::listenLoop, "power-listener");
        listener.setDaemon(true);
        listener.start();
    }

    private void listenLoop() {
        while (running) {
            try {
                String devs = findPowerDevices();
                if (devs.isEmpty()) {
                    Thread.sleep(10000);
                    continue;
                }
                proc = new ProcessBuilder("su", "-c", "getevent -l " + devs)
                        .redirectErrorStream(true).start();
                BufferedReader r = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.contains("KEY_POWER") && line.contains("DOWN")) {
                        onPowerDown(SystemClock.elapsedRealtime());
                    }
                }
            } catch (Exception ignored) {
            } finally {
                Process p = proc;
                if (p != null) p.destroy();
            }
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    private String findPowerDevices() {
        StringBuilder sb = new StringBuilder();
        try {
            Process p = new ProcessBuilder("su", "-c", "getevent -pl").redirectErrorStream(true).start();
            p.getOutputStream().close();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String cur = null, line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("add device")) {
                    int i = line.lastIndexOf(": ");
                    cur = i >= 0 ? line.substring(i + 2).trim() : null;
                } else if (cur != null && line.contains("KEY_POWER")) {
                    if (sb.indexOf(cur) < 0) sb.append(cur).append(' ');
                }
            }
            p.waitFor();
        } catch (Exception ignored) {
        }
        return sb.toString().trim();
    }

    private synchronized void onPowerDown(long now) {
        if (lastDown != 0 && now - lastDown <= TAP_MS) {
            lastDown = 0;
            fire();
        } else {
            lastDown = now;
        }
    }

    private synchronized void fire() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastFire < DEBOUNCE_MS) return;
        lastFire = now;
        final Context c = getApplicationContext();
        new Thread(() -> {
            try {
                Thread.sleep(600);
                Brightness.apply(c);
                Thread.sleep(700);
                Brightness.apply(c);
                Thread.sleep(1200);
                Brightness.apply(c);
            } catch (InterruptedException ignored) {
            }
        }).start();
    }

    private void stop() {
        running = false;
        Process p = proc;
        if (p != null) p.destroy();
        if (listener != null) listener.interrupt();
        if (screenRx != null) {
            try {
                unregisterReceiver(screenRx);
            } catch (Exception ignored) {
            }
            screenRx = null;
        }
    }

    @Override
    public boolean onUnbind(Intent intent) {
        stop();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        stop();
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }
}
