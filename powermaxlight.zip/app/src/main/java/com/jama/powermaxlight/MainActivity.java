package com.jama.powermaxlight;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        status = new TextView(this);
        status.setTextSize(16);
        root.addView(status);

        root.addView(button("Enable service (root)", v -> enableRoot()));
        root.addView(button("Open accessibility settings", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Allow modify system settings (optional)", v ->
                startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        Uri.parse("package:" + getPackageName())))));
        root.addView(button("Test max brightness", v -> new Thread(() -> Brightness.apply(this)).start()));

        setContentView(root);
    }

    private Button button(String t, View.OnClickListener l) {
        Button x = new Button(this);
        x.setText(t);
        x.setAllCaps(false);
        x.setOnClickListener(l);
        return x;
    }

    @Override
    protected void onResume() {
        super.onResume();
        status.setText("Service: " + (isEnabled() ? "ON" : "OFF") + "\nDouble tap the power button to set max brightness.");
    }

    private String component() {
        return new ComponentName(this, PowerAccessibilityService.class).flattenToString();
    }

    private boolean isEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(component());
    }

    private void enableRoot() {
        new Thread(() -> {
            Brightness.runRoot("pm grant " + getPackageName() + " android.permission.WRITE_SECURE_SETTINGS");
            String msg;
            try {
                String cur = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
                String cn = component();
                if (cur == null || cur.isEmpty()) cur = cn;
                else if (!cur.contains(cn)) cur = cur + ":" + cn;
                Settings.Secure.putString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, cur);
                Settings.Secure.putInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
                msg = "Enabled";
            } catch (Exception e) {
                msg = "Failed: " + e.getMessage();
            }
            final String m = msg;
            runOnUiThread(() -> {
                Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
                onResume();
            });
        }).start();
    }
}
